package com.lti.dao;

import java.util.List;

import com.lti.model.City;
import com.lti.model.Hostel;
import com.lti.model.Login;
import com.lti.model.Occupation;
import com.lti.model.SelfEmployeeDetails;
import com.lti.model.State;
import com.lti.model.StepFamilyDetails;
import com.lti.model.StepPersonalDetails;
import com.lti.model.StepRegister;
import com.lti.model.Trainee;
import com.lti.model.Training;


public interface WomaniaDao {
	//login details
	public int verifyUser(Login login);
	
	
	//select data from table
	public List<StepRegister> readAllStepDetails();
	public List<StepPersonalDetails> readStepPersonalDetails();
	public List<Occupation> readStepOccupationDetails();
	public List<StepPersonalDetails> readStepPersonalWithOccupation();
	public List<StepFamilyDetails> readStepFamilyDetails();
	public List<City> readCity();
	public List<State> readState();
	public List<Hostel> readHostel();
	public List<Training> readTrainingDetails();
	public List<Trainee> readTraineeDetails();
	public List<SelfEmployeeDetails> readSelfEmployeeDetails();
	
	
	//insert data to table
	public int createStep(StepRegister step);
	public int createStepPersonalDetails(StepPersonalDetails person);
	public int createStepFamilyDetails(StepFamilyDetails family);
	
}
