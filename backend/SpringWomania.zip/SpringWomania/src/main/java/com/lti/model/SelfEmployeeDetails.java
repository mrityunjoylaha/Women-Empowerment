package com.lti.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("selfEmployeeDeatails")
@Entity
@Table(name = "SelfEmployee_Details")
@SequenceGenerator(name = "seq_selfemployed", sequenceName = "seq_selfemployed", allocationSize = 1, initialValue = 1)
public class SelfEmployeeDetails implements Serializable{
	@Id
	@Column(name = "serial_no")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_selfemployed")
	private int serialNo;
	@Column(name = "company_name")
	private String company_name;
	@Column(name = "designation")
	private String designation;
	@Column(name = "location")
	private String location;
	@Column(name = "salary")
	private int salary;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "pid")
	private StepPersonalDetails personalDetails;

	@ManyToOne
	@Autowired
	@JoinColumn(name = "hostel_id")
	private Hostel hostel;

	public SelfEmployeeDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SelfEmployeeDetails(int serialNo, String company_name, String designation, String location, int salary,
			StepPersonalDetails personalDetails, Hostel hostel) {
		super();
		this.serialNo = serialNo;
		this.company_name = company_name;
		this.designation = designation;
		this.location = location;
		this.salary = salary;
		this.personalDetails = personalDetails;
		this.hostel = hostel;
	}

	public int getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public StepPersonalDetails getPersonalDetails() {
		return personalDetails;
	}

	public void setPersonalDetails(StepPersonalDetails personalDetails) {
		this.personalDetails = personalDetails;
	}

	public Hostel getHostel() {
		return hostel;
	}

	public void setHostel(Hostel hostel) {
		this.hostel = hostel;
	}

	@Override
	public String toString() {
		return "SelfEmployeeDetails [serialNo=" + serialNo + ", company_name=" + company_name + ", designation="
				+ designation + ", location=" + location + ", salary=" + salary + ", personalDetails=" + personalDetails
				+ ", hostel=" + hostel + "]";
	}

}
