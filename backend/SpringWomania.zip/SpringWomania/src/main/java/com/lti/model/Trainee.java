package com.lti.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component("trainee")
@Entity
@Table(name = "Trainee")
@SequenceGenerator(name="seq_trainee",sequenceName="seq_trainee",allocationSize=1,initialValue=1)
public class Trainee implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq_trainee")
	@Column(name = "trainee_Id")
	private int traineeId;
	@Column(name = "course_opt")
	private String courseOpt;
	@Column(name = "start_date")
	private Date startDate;
	@Column(name = "end_date")
	private Date endDate;

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="pid")
	private StepPersonalDetails personalDetails;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="training_id")
	private Training training;
	
	@ManyToOne
	@JoinColumn(name="hostel_id")
	private Hostel hostel;

	public Trainee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Trainee(int traineeId, String courseOpt, Date startDate, Date endDate, StepPersonalDetails personalDetails,
			Training training) {
		super();
		this.traineeId = traineeId;
		this.courseOpt = courseOpt;
		this.startDate = startDate;
		this.endDate = endDate;
		this.personalDetails = personalDetails;
		this.training = training;
	}

	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	public String getCourseOpt() {
		return courseOpt;
	}

	public void setCourseOpt(String courseOpt) {
		this.courseOpt = courseOpt;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public StepPersonalDetails getPersonalDetails() {
		return personalDetails;
	}

	public void setPersonalDetails(StepPersonalDetails personalDetails) {
		this.personalDetails = personalDetails;
	}

	public Training getTraining() {
		return training;
	}

	public void setTraining(Training training) {
		this.training = training;
	}

	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", courseOpt=" + courseOpt + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", personalDetails=" + personalDetails + ", training=" + training + "]";
	}

}
